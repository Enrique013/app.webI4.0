package mx.edu.utez.ExamenDiagnostico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class ExamenDiagnosticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenDiagnosticoApplication.class, args);
	}

}
